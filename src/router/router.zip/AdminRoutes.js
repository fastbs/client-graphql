import AdminMain from "@/components/Admin/AdminMain";

const routes = [
  {
    path: "/admin",
    name: "AdminMain",
    component: AdminMain
  }
];

export default routes;
